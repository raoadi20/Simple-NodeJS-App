# simple-nodejs-web-app
## Overview

* Very simple Node.js web application
* You can create, read, update, and delete your text via this application.

## Notes

* This is for reviewing [my Node.js practice](https://github.com/mwjjeong/nodejs-practice).

* User interface is somewhat rough but will be improved.

* Current security level is low but will be improved.

## References

* [Openturorials Node.js courses for beginners](https://opentutorials.org/course/3332)
* [Official Node.js API documentation](https://nodejs.org/en/docs/)

  

  

