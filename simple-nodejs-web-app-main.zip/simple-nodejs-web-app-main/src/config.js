exports.port = 8080;
exports.dataDir = `${__dirname}/../data`;